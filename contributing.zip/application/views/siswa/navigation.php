<a href="<?php echo base_url('berandasiswa')?>" class="btn btn-primary"><i class="fa fa-calendar"> Jadwal</i></a>
<a href="<?php echo base_url('pengumumansiswa')?>" class="btn btn-warning"><i class="fa fa-list-alt"> Pengumuman</i></a>
<a href="<?php echo base_url('materisiswa')?>" class="btn btn-success"><i class="fa fa-book"> Materi</i></a>
<a href="<?php echo base_url('ujiansiswa')?>" class="btn btn-info"><i class="fa fa-list-ol"> Ujian</i></a>
<a href="<?php echo base_url('profilsiswa')?>" class="btn btn-danger"><i class="fa fa-user"> Profil</i></a>
<!-- <a href="" class="btn btn-danger"><i class="fa fa-child"> SISWA</i></a> -->