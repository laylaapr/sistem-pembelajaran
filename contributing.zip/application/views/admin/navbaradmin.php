<section class="ftco-section" style="background: #CD5D7D">
  
  <div class="container">
    <div class="row justify-content-between">
      <div class="col">
        <a class="navbar-brand" href="<?php echo base_url('')?>">SISTEM ADMIN<span class="text-white">Computer Adaptive Testing</span></a>
      </div>
      <div class="col d-flex justify-content-end">
        <div class="social-media">
          <p class="mb-0 d-flex">
            <a href="<?php echo base_url('admin')?>" class="d-flex align-items-center justify-content-center"><span class="fa fa-home"><i class="sr-only">Beranda</i></span></a>
            <a href="<?php echo base_url('logout')?>" class="d-flex align-items-center justify-content-center"><span class="fa fa-sign-out"><i class="sr-only">LOGOUT</i></span></a>

          </p>
        </div>
      </div>
    </div>
  </div>

</section>