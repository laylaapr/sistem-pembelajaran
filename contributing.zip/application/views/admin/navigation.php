<a href="<?php echo base_url('admin')?>" class="btn btn-info"><i class="fa fa-home"> Beranda</i></a>
<a href="<?php echo base_url('guruadmin')?>" class="btn btn-warning"><i class="fa fa-user"> Guru</i></a>
<a href="<?php echo base_url('matpeladmin')?>" class="btn btn-danger"><i class="fa fa-list"> Matpel</i></a>
<a href="<?php echo base_url('siswaadmin')?>" class="btn btn-success"><i class="fa fa-child"> Siswa</i></a>
<a href="<?php echo base_url('tambahjadwal')?>" class="btn btn-primary"><i class="fa fa-calendar-o"> Jadwal</i></a>