<!-- Footer -->

<!-- Section: Social media -->
<section
         class="d-flex justify-content-between p-4 text-white" style="background: #CD5D7D; height: 70px;"
         >




  
  <p class="text-white"
    >© 2022</a
    >
</div>
<!-- Copyright -->
</footer>
<!-- Footer -->


<script src="<?php echo base_url('assets/js/jquery.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/popper.js')?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/main.js')?>"></script>