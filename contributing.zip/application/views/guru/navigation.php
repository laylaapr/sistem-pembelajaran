<a href="<?php echo base_url('jadwalguru/'.$_SESSION['jadwalguru'])?>" class="btn btn-primary"><i class="fa fa-list-ol"> COURSE</i></a>
<a href="<?php echo base_url('ujianguru')?>" class="btn btn-info"><i class="fa fa-list-ol"> UJIAN</i></a>
<a href="<?php echo base_url('materi')?>" class="btn btn-warning"><i class="fa fa-list-alt"> MATERI</i></a>
<a href="<?php echo base_url('siswaguru')?>" class="btn btn-danger"><i class="fa fa-child"> SISWA</i></a>