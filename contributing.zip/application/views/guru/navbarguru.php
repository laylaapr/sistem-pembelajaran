<section class="ftco-section" style="background: #CD5D7D">
  
  <div class="container">
    <div class="row justify-content-between">
      <div class="col">
        <a class="navbar-brand" href="<?php echo base_url('')?>">SISTEM GURU<span class="text-white">Computer Adaptive Testing</span></a>
      </div>
      <div class="col d-flex justify-content-end">
        <div class="social-media">
          <p class="mb-0 d-flex">
            <a href="<?php echo base_url('guru')?>" class="d-flex align-items-center justify-content-center"><span class="fa fa-home"><i class="sr-only">Beranda</i></span></a>
<!--             <a href="#" class="d-flex align-items-center justify-content-center"><span class="fa fa-instagram"><i class="sr-only">Instagram</i></span></a> -->
            <a href="<?php echo base_url('logout')?>" class="d-flex align-items-center justify-content-center"><span class="fa fa-sign-out"><i class="sr-only">LOGOUT</i></span></a>

          </p>
        </div>
      </div>
    </div>
  </div>
<!--   <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar ftco-navbar-light" id="ftco-navbar">
    <div class="container">
    
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="fa fa-bars"></span> Menu
      </button>
      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item"><a href="<?php echo base_url('')?>" class="nav-link">Beranda</a></li>
          <li class="nav-item"><a href="<?php echo base_url('profil')?>" class="nav-link">Profil</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Unit Pendidikan</a>
            <div class="dropdown-menu" aria-labelledby="dropdown04">
              <a class="dropdown-item" href="<?php echo base_url('tk')?>">TK</a>
              <a class="dropdown-item" href="<?php echo base_url('tpq')?>">TPQ</a>
              <a class="dropdown-item" href="<?php echo base_url('sd')?>">SD</a>
            </div>
          </li>
          <li class="nav-item"><a href="<?php echo base_url('informasi')?>" class="nav-link">Berita & Informasi</a></li>
          <li class="nav-item"><a href="<?php echo base_url('pendaftaran')?>" class="nav-link">Pendaftaran Online</a></li>
          <li class="nav-item"><a href="<?php echo base_url('kontak')?>" class="nav-link">Kontak</a></li>
        </ul>
      </div>
    </div>
  </nav> -->
</section>